package com.Rafa.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Sorteado(View v){

        TextView texto = findViewById(R.id.TextResult);

        int min = 50;
        int max = 100;

        int NumSorte = new Random().nextInt(( max - min)+1)+min;

        texto.setText("Número Sorteado:" +NumSorte);
    }
}