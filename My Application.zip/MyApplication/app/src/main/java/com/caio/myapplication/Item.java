package com.caio.myapplication;

public class Item {
    public Item(Integer id, String name, int photo) {
        this.id = id;
        this.name = name;
        this.photo = photo;
    }

    Integer id;
    String name;
    int photo;
}
