package com.caio.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView lv = (ListView) findViewById(R.id.listView);
        ArrayList<Item> arrayList = new ArrayList<Item>();
        arrayList.add(new Item(1, "Cachorro", R.drawable.cachorro));
        arrayList.add(new Item(2, "gardem", R.drawable.gardem));
        arrayList.add(new Item(3, "happy", R.drawable.happy));
        ItensAdapter itensAdapter = new ItensAdapter(this, R.layout.item_lista, arrayList);
        lv.setAdapter(itensAdapter);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Obtém o item clicado na posição 'i' da lista
                Item itemClicado = arrayList.get(i);

                // Exibe um Toast com o nome do item
                Toast.makeText(getApplicationContext(), "Item selecionado: " + itemClicado.name, Toast.LENGTH_SHORT).show();
            }
        });

    }
}