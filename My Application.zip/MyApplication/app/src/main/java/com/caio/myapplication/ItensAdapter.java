package com.caio.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class ItensAdapter extends ArrayAdapter<Item> {
    int mResorse;
    public ItensAdapter(@NonNull Context context, int resource, @NonNull List objects) {
        super(context, resource, objects);
        mResorse = resource;
    }
    @NonNull
    @Override
    public View getView(int position, @NonNull View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View v = inflater.inflate(mResorse, parent, false);

        // Obtenha o item na posição especificada
        Item item = getItem(position);

        // Verifique se o item não é nulo e defina as visualizações com base no item
        if (item != null) {
            // Suponhamos que você tenha uma TextView no layout com o ID "textViewNome"
            TextView textViewNome = v.findViewById(R.id.txtItemLista);
            ImageView imageView = v.findViewById(R.id.imageView);

            // Defina o texto da TextView com base nas informações do item
            textViewNome.setText(item.name);
            imageView.setImageResource(item.photo);

            // Você pode fazer o mesmo para outras visualizações no layout, se necessário.
        }

        return v;

    }
}
